"""
🏆 AI TOURNAMENT API BACKEND
================================

REST API for integrating tournament into stock analysis software
Replaces Oracle AI with 4-team tournament system

Endpoints:
  GET  /api/analysis/{symbol}        - Get full analysis for stock
  GET  /api/consensus/strong         - Get high-conviction stocks
  GET  /api/tournament/leaderboard   - Get team standings
  GET  /api/team/{team_id}/stats     - Get team performance
  POST /api/analysis/batch           - Analyze multiple stocks
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import sqlite3
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import logging

# Import your tournament system
try:
    from ultimate_trading_tournament import (
        RecursiveTournamentOrchestrator,
        TournamentConfig,
        TradeAction
    )
    TOURNAMENT_AVAILABLE = True
except ImportError:
    TOURNAMENT_AVAILABLE = False
    print("⚠️  Tournament system not found. Install or check path.")

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ============================================================================
# GLOBAL STATE
# ============================================================================

class TournamentAPIManager:
    """Manages tournament state for API"""
    
    def __init__(self):
        self.config = None
        self.orchestrator = None
        self.db_path = "ultimate_tournament.db"
        self.initialized = False
        
    def initialize(self):
        """Initialize tournament system"""
        if self.initialized:
            return True
            
        try:
            self.config = TournamentConfig()
            self.orchestrator = RecursiveTournamentOrchestrator(self.config)
            self.initialized = True
            logger.info("✅ Tournament API initialized")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to initialize: {e}")
            return False
    
    def get_stock_analysis(self, symbol: str) -> Dict:
        """Get complete analysis for a stock"""
        if not self.initialized:
            return {"error": "Tournament not initialized"}
        
        # Get latest recommendations for this symbol
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get team recommendations (last 24 hours)
        cursor.execute("""
            SELECT 
                team_id,
                team_name,
                action,
                confidence,
                target_price,
                stop_loss,
                reasoning,
                key_factors,
                timestamp
            FROM team_recommendations
            WHERE symbol = ?
            AND timestamp > datetime('now', '-1 day')
            ORDER BY timestamp DESC
        """, (symbol,))
        
        recs = cursor.fetchall()
        
        if not recs:
            conn.close()
            return {
                "error": "No recent analysis",
                "symbol": symbol,
                "message": "No recommendations in last 24 hours"
            }
        
        # Get team stats
        cursor.execute("""
            SELECT 
                team_id,
                current_equity,
                total_return_pct,
                win_rate,
                total_trades
            FROM portfolio_snapshots
            WHERE date = (SELECT MAX(date) FROM portfolio_snapshots)
        """)
        
        team_stats = {row[0]: {
            'equity': row[1],
            'return': row[2],
            'win_rate': row[3],
            'trades': row[4]
        } for row in cursor.fetchall()}
        
        conn.close()
        
        # Build response
        teams = []
        actions = []
        confidences = []
        targets = []
        stops = []
        
        for rec in recs:
            team_id = rec[0]
            action = rec[2]
            confidence = rec[3]
            
            actions.append(action)
            confidences.append(confidence)
            if rec[4]: targets.append(rec[4])
            if rec[5]: stops.append(rec[5])
            
            teams.append({
                'team_id': team_id,
                'team_name': rec[1],
                'action': action,
                'confidence': confidence,
                'target_price': rec[4],
                'stop_loss': rec[5],
                'reasoning_short': rec[6][:200] if rec[6] else "",
                'reasoning_full': rec[6],
                'key_factors': json.loads(rec[7]) if rec[7] else [],
                'timestamp': rec[8],
                'stats': team_stats.get(team_id, {})
            })
        
        # Calculate consensus
        buy_actions = ['BUY', 'STRONG_BUY']
        sell_actions = ['SELL', 'STRONG_SELL']
        
        buy_count = sum(1 for a in actions if a in buy_actions)
        sell_count = sum(1 for a in actions if a in sell_actions)
        total = len(actions)
        
        # Determine consensus
        if buy_count == total:
            consensus = "STRONG_BUY"
            strength = "unanimous"
        elif sell_count == total:
            consensus = "STRONG_SELL"
            strength = "unanimous"
        elif buy_count >= total * 0.75:
            consensus = "BUY"
            strength = "strong"
        elif sell_count >= total * 0.75:
            consensus = "SELL"
            strength = "strong"
        elif buy_count > sell_count:
            consensus = "BUY"
            strength = "weak"
        elif sell_count > buy_count:
            consensus = "SELL"
            strength = "weak"
        else:
            consensus = "HOLD"
            strength = "no_consensus"
        
        return {
            'symbol': symbol,
            'timestamp': datetime.now().isoformat(),
            'consensus': {
                'recommendation': consensus,
                'strength': strength,
                'agree_count': max(buy_count, sell_count),
                'total_teams': total,
                'avg_confidence': sum(confidences) / len(confidences) if confidences else 0,
                'target_avg': sum(targets) / len(targets) if targets else None,
                'stop_avg': sum(stops) / len(stops) if stops else None,
                'suggested_action': consensus
            },
            'teams': teams,
            'tournament_day': self._get_tournament_day()
        }
    
    def get_consensus_stocks(self, min_agreement: int = 3) -> List[Dict]:
        """Get stocks where teams agree"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get recent recommendations grouped by symbol
        cursor.execute("""
            SELECT 
                symbol,
                COUNT(*) as team_count,
                GROUP_CONCAT(action) as actions,
                AVG(confidence) as avg_confidence
            FROM team_recommendations
            WHERE timestamp > datetime('now', '-1 day')
            GROUP BY symbol
            HAVING team_count >= ?
        """, (min_agreement,))
        
        results = []
        for row in cursor.fetchall():
            symbol = row[0]
            actions = row[2].split(',')
            
            # Check if majority agree
            buy_count = sum(1 for a in actions if a in ['BUY', 'STRONG_BUY'])
            sell_count = sum(1 for a in actions if a in ['SELL', 'STRONG_SELL'])
            
            if buy_count >= min_agreement or sell_count >= min_agreement:
                results.append({
                    'symbol': symbol,
                    'agree_count': max(buy_count, sell_count),
                    'total_teams': row[1],
                    'recommendation': 'BUY' if buy_count > sell_count else 'SELL',
                    'avg_confidence': row[3]
                })
        
        conn.close()
        return results
    
    def get_leaderboard(self) -> Dict:
        """Get tournament standings"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get latest portfolio snapshots
        cursor.execute("""
            SELECT 
                team_id,
                team_name,
                current_equity,
                total_return_pct,
                max_drawdown,
                win_rate,
                total_trades,
                api_costs,
                sharpe_ratio,
                sortino_ratio
            FROM portfolio_snapshots
            WHERE date = (SELECT MAX(date) FROM portfolio_snapshots)
            ORDER BY total_return_pct DESC
        """)
        
        teams = []
        rank = 1
        for row in cursor.fetchall():
            teams.append({
                'rank': rank,
                'team_id': row[0],
                'team_name': row[1],
                'equity': row[2],
                'return_pct': row[3],
                'max_drawdown': row[4],
                'win_rate': row[5],
                'total_trades': row[6],
                'api_costs': row[7],
                'sharpe_ratio': row[8],
                'sortino_ratio': row[9]
            })
            rank += 1
        
        conn.close()
        
        return {
            'teams': teams,
            'tournament_day': self._get_tournament_day(),
            'total_days': 90,
            'last_updated': datetime.now().isoformat()
        }
    
    def get_team_stats(self, team_id: int) -> Dict:
        """Get detailed stats for a team"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get team info
        cursor.execute("""
            SELECT 
                team_name,
                current_equity,
                total_return_pct,
                win_rate,
                total_trades,
                winning_trades,
                losing_trades
            FROM portfolio_snapshots
            WHERE team_id = ?
            AND date = (SELECT MAX(date) FROM portfolio_snapshots)
        """, (team_id,))
        
        team_data = cursor.fetchone()
        
        if not team_data:
            conn.close()
            return {'error': 'Team not found'}
        
        # Get recent recommendations
        cursor.execute("""
            SELECT 
                symbol,
                action,
                confidence,
                timestamp
            FROM team_recommendations
            WHERE team_id = ?
            ORDER BY timestamp DESC
            LIMIT 10
        """, (team_id,))
        
        recent_recs = [
            {
                'symbol': row[0],
                'action': row[1],
                'confidence': row[2],
                'timestamp': row[3]
            }
            for row in cursor.fetchall()
        ]
        
        # Get daily performance (last 30 days)
        cursor.execute("""
            SELECT 
                date,
                daily_return_pct
            FROM daily_pnl
            WHERE team_id = ?
            ORDER BY date DESC
            LIMIT 30
        """, (team_id,))
        
        daily_performance = [
            {'date': row[0], 'return': row[1]}
            for row in cursor.fetchall()
        ]
        
        conn.close()
        
        return {
            'team_id': team_id,
            'team_name': team_data[0],
            'current_equity': team_data[1],
            'total_return': team_data[2],
            'win_rate': team_data[3],
            'total_trades': team_data[4],
            'winning_trades': team_data[5],
            'losing_trades': team_data[6],
            'recent_recommendations': recent_recs,
            'daily_performance': daily_performance
        }
    
    def _get_tournament_day(self) -> int:
        """Get current tournament day"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(DISTINCT date) FROM portfolio_snapshots")
        day = cursor.fetchone()[0]
        conn.close()
        return day

# Initialize manager
manager = TournamentAPIManager()

# ============================================================================
# API ENDPOINTS
# ============================================================================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'tournament_initialized': manager.initialized,
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/init', methods=['POST'])
def initialize_tournament():
    """Initialize tournament system"""
    success = manager.initialize()
    return jsonify({
        'success': success,
        'message': 'Tournament initialized' if success else 'Failed to initialize'
    })

@app.route('/api/analysis/<symbol>', methods=['GET'])
def get_stock_analysis(symbol):
    """
    Get AI tournament analysis for a stock
    
    Returns:
        - Consensus recommendation
        - All team recommendations
        - Team stats
    """
    try:
        symbol = symbol.upper()
        analysis = manager.get_stock_analysis(symbol)
        return jsonify(analysis)
    except Exception as e:
        logger.error(f"Error analyzing {symbol}: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/analysis/batch', methods=['POST'])
def batch_analysis():
    """
    Analyze multiple stocks at once
    
    Body: {"symbols": ["AAPL", "MSFT", "GOOGL"]}
    """
    try:
        data = request.json
        symbols = data.get('symbols', [])
        
        results = {}
        for symbol in symbols:
            results[symbol] = manager.get_stock_analysis(symbol.upper())
        
        return jsonify(results)
    except Exception as e:
        logger.error(f"Batch analysis error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/consensus/strong', methods=['GET'])
def get_strong_consensus():
    """
    Get stocks where teams strongly agree
    
    Query params:
        - min_agreement: Minimum number of teams that must agree (default: 3)
    """
    try:
        min_agreement = int(request.args.get('min_agreement', 3))
        stocks = manager.get_consensus_stocks(min_agreement)
        return jsonify({
            'stocks': stocks,
            'min_agreement': min_agreement,
            'count': len(stocks)
        })
    except Exception as e:
        logger.error(f"Consensus error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/tournament/leaderboard', methods=['GET'])
def get_leaderboard():
    """Get tournament standings"""
    try:
        leaderboard = manager.get_leaderboard()
        return jsonify(leaderboard)
    except Exception as e:
        logger.error(f"Leaderboard error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/team/<int:team_id>/stats', methods=['GET'])
def get_team_stats(team_id):
    """Get detailed stats for a team"""
    try:
        stats = manager.get_team_stats(team_id)
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Team stats error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/tournament/status', methods=['GET'])
def get_tournament_status():
    """Get overall tournament status"""
    try:
        conn = sqlite3.connect(manager.db_path)
        cursor = conn.cursor()
        
        # Get basic stats
        cursor.execute("SELECT COUNT(DISTINCT symbol) FROM team_recommendations")
        stocks_analyzed = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM team_recommendations")
        total_recommendations = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT date) FROM portfolio_snapshots")
        days_running = cursor.fetchone()[0]
        
        conn.close()
        
        return jsonify({
            'days_running': days_running,
            'stocks_analyzed': stocks_analyzed,
            'total_recommendations': total_recommendations,
            'initialized': manager.initialized
        })
    except Exception as e:
        logger.error(f"Status error: {e}")
        return jsonify({'error': str(e)}), 500

# ============================================================================
# WEBSOCKET SUPPORT (Optional - for real-time updates)
# ============================================================================

try:
    from flask_socketio import SocketIO, emit
    socketio = SocketIO(app, cors_allowed_origins="*")
    
    @socketio.on('connect')
    def handle_connect():
        emit('status', {'message': 'Connected to tournament'})
    
    @socketio.on('subscribe_symbol')
    def handle_subscribe(data):
        symbol = data.get('symbol')
        # Send real-time updates for this symbol
        analysis = manager.get_stock_analysis(symbol)
        emit('analysis_update', analysis)
    
    SOCKETIO_AVAILABLE = True
except ImportError:
    SOCKETIO_AVAILABLE = False
    socketio = None
    logger.info("SocketIO not available - real-time updates disabled")

# ============================================================================
# RUN SERVER
# ============================================================================

if __name__ == '__main__':
    # Initialize on startup
    logger.info("🚀 Starting AI Tournament API...")
    manager.initialize()
    
    # Run server
    if SOCKETIO_AVAILABLE and socketio:
        socketio.run(app, host='0.0.0.0', port=5000, debug=True)
    else:
        app.run(host='0.0.0.0', port=5000, debug=True)
