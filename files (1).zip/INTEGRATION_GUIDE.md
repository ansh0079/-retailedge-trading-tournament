# 🏆 AI TOURNAMENT INTEGRATION GUIDE - APPROACH 1
## Complete Replacement of Oracle AI

This guide shows how to integrate the 4-team AI tournament into your stock analysis software, replacing the existing Oracle AI completely.

---

## 📁 Files Provided

1. **`tournament_api_backend.py`** - Flask REST API
2. **`TournamentComponents.jsx`** - React frontend components
3. **`tournament_styles.css`** - Complete styling
4. **This guide** - Integration instructions

---

## 🚀 Quick Start (5 Steps)

### **Step 1: Start the Backend API**

```bash
# Install dependencies
pip install flask flask-cors flask-socketio

# Start the API server
python tournament_api_backend.py

# Server runs on http://localhost:5000
```

**Test it works:**
```bash
curl http://localhost:5000/api/health
# Should return: {"status": "ok", ...}
```

---

### **Step 2: Install Frontend Dependencies**

```bash
# In your React project
npm install axios
```

---

### **Step 3: Import Components**

```jsx
// In your stock analysis page component
import { 
  TournamentAnalysis,
  TournamentLeaderboard,
  ConsensusAlerts 
} from './TournamentComponents';
import './tournament_styles.css';
```

---

### **Step 4: Replace Oracle AI**

**BEFORE (with Oracle):**
```jsx
<StockAnalysisPage symbol={symbol}>
  <Chart symbol={symbol} />
  <Fundamentals symbol={symbol} />
  <OracleAI symbol={symbol} />  {/* OLD */}
</StockAnalysisPage>
```

**AFTER (with Tournament):**
```jsx
<StockAnalysisPage symbol={symbol}>
  <Chart symbol={symbol} />
  <Fundamentals symbol={symbol} />
  <TournamentAnalysis symbol={symbol} />  {/* NEW */}
</StockAnalysisPage>
```

---

### **Step 5: Add Sidebar Leaderboard (Optional)**

```jsx
<MainLayout>
  <Sidebar>
    <YourExistingSidebarContent />
    <TournamentLeaderboard compact={true} />
  </Sidebar>
  
  <MainContent>
    {/* Your stock analysis pages */}
  </MainContent>
</MainLayout>
```

---

## 🎨 Full Integration Example

### **Complete Stock Analysis Page**

```jsx
import React, { useState } from 'react';
import { 
  TournamentAnalysis, 
  TournamentLeaderboard,
  ConsensusAlerts 
} from './TournamentComponents';
import './tournament_styles.css';

export const StockAnalysisPage = ({ symbol }) => {
  const [showLeaderboard, setShowLeaderboard] = useState(true);
  
  return (
    <div className="stock-analysis-page">
      {/* Your existing components */}
      <div className="chart-section">
        <StockChart symbol={symbol} />
      </div>
      
      <div className="fundamentals-section">
        <Fundamentals symbol={symbol} />
      </div>
      
      {/* NEW: Tournament Analysis (replaces Oracle AI) */}
      <div className="ai-analysis-section">
        <TournamentAnalysis symbol={symbol} />
      </div>
      
      {/* NEW: High Conviction Alerts */}
      <ConsensusAlerts />
      
      {/* Optional: Show leaderboard on page */}
      {showLeaderboard && (
        <div className="sidebar-section">
          <TournamentLeaderboard compact={false} />
        </div>
      )}
    </div>
  );
};
```

---

## 📊 API Endpoints Reference

### **1. Get Stock Analysis**
```javascript
GET /api/analysis/{symbol}

// Example
fetch('http://localhost:5000/api/analysis/AAPL')
  .then(res => res.json())
  .then(data => console.log(data));

// Returns:
{
  "symbol": "AAPL",
  "consensus": {
    "recommendation": "STRONG_BUY",
    "strength": "unanimous",
    "agree_count": 4,
    "total_teams": 4,
    "avg_confidence": 86
  },
  "teams": [
    {
      "team_id": 1,
      "team_name": "Claude Opus 4.5",
      "action": "BUY",
      "confidence": 88,
      "target_price": 201,
      "stop_loss": 177
    },
    // ... other teams
  ]
}
```

### **2. Get Tournament Standings**
```javascript
GET /api/tournament/leaderboard

// Returns current rankings and stats
```

### **3. Get High Conviction Stocks**
```javascript
GET /api/consensus/strong?min_agreement=4

// Returns stocks where all/most teams agree
```

### **4. Batch Analysis**
```javascript
POST /api/analysis/batch
Body: {"symbols": ["AAPL", "MSFT", "GOOGL"]}

// Analyze multiple stocks at once
```

---

## 🎯 Component Usage Examples

### **Basic Usage**

```jsx
// Simple analysis display
<TournamentAnalysis symbol="AAPL" />
```

### **With Custom Styling**

```jsx
<div className="my-custom-container">
  <TournamentAnalysis symbol="AAPL" />
</div>
```

### **Compact Leaderboard (Sidebar)**

```jsx
<Sidebar>
  <TournamentLeaderboard compact={true} />
</Sidebar>
```

### **Full Leaderboard (Dedicated Page)**

```jsx
<TournamentLeaderboard compact={false} />
```

### **Consensus Alerts**

```jsx
// Shows when all 4 teams agree
<ConsensusAlerts />
```

---

## 🔧 Customization Options

### **Change API URL**

```bash
# .env file
REACT_APP_API_URL=http://your-server:5000/api
```

### **Custom Styling**

```css
/* Override default styles in your CSS */
.tournament-analysis {
  /* Your custom styles */
  background: your-color;
  border-radius: your-radius;
}
```

### **Disable Certain Features**

```jsx
// Don't show leaderboard
<TournamentAnalysis 
  symbol="AAPL" 
  showLeaderboard={false} 
/>

// Don't show team details by default
<TournamentAnalysis 
  symbol="AAPL"
  defaultShowDetails={false}
/>
```

---

## 📱 Mobile Responsive

The components are fully responsive and work great on mobile:

- Stacks vertically on small screens
- Touch-friendly buttons
- Optimized font sizes
- Simplified layouts for mobile

---

## 🔄 Real-time Updates (Optional)

### **Using WebSockets**

```bash
# Install socket.io client
npm install socket.io-client
```

```jsx
import io from 'socket.io-client';

const socket = io('http://localhost:5000');

socket.on('analysis_update', (data) => {
  // Update UI with new analysis
  console.log('New analysis:', data);
});

// Subscribe to a symbol
socket.emit('subscribe_symbol', { symbol: 'AAPL' });
```

---

## 🎨 UI States

### **Loading State**

```jsx
<TournamentAnalysis symbol="AAPL" />
// Shows spinner and "Loading AI Tournament Analysis..."
```

### **Error State**

```jsx
// When API fails, shows:
// "❌ Error loading analysis"
// [Retry Button]
```

### **No Data State**

```jsx
// When no recent analysis:
// "No recent tournament analysis for AAPL"
// "Analysis updates daily at market close"
```

### **Success State**

```jsx
// Shows full consensus view with team details
```

---

## 🚦 Testing Your Integration

### **1. Test Backend API**

```bash
# Health check
curl http://localhost:5000/api/health

# Get analysis
curl http://localhost:5000/api/analysis/AAPL

# Get leaderboard
curl http://localhost:5000/api/tournament/leaderboard
```

### **2. Test Frontend**

```bash
# Start your React app
npm start

# Navigate to a stock page
# You should see tournament analysis instead of Oracle AI
```

### **3. Check Console**

Open browser DevTools and check for:
- No errors in Console
- API calls succeeding in Network tab
- Components rendering correctly

---

## 🐛 Troubleshooting

### **"Failed to load analysis"**

**Solution:**
```bash
# 1. Check backend is running
curl http://localhost:5000/api/health

# 2. Check CORS is enabled
# Should see "Access-Control-Allow-Origin: *" in response headers

# 3. Check database exists
ls ultimate_tournament.db
```

### **Components not styling correctly**

**Solution:**
```jsx
// Make sure CSS is imported
import './tournament_styles.css';

// Check CSS file is in correct location
```

### **"Tournament not initialized"**

**Solution:**
```bash
# Initialize tournament first
curl -X POST http://localhost:5000/api/init
```

---

## 📊 Database Schema

The backend uses SQLite with these tables:

```sql
team_recommendations    -- All AI recommendations
portfolio_snapshots     -- Daily team performance
daily_pnl              -- Daily P&L tracking
positions              -- Active and closed positions
review_decisions       -- Reviewer approvals/rejections
```

**Location:** `ultimate_tournament.db`

---

## 🔐 Production Deployment

### **Backend (API Server)**

```bash
# Use production WSGI server
pip install gunicorn

# Run with gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 tournament_api_backend:app
```

### **Frontend (React App)**

```bash
# Build for production
npm run build

# Update API URL for production
REACT_APP_API_URL=https://your-api-server.com/api npm run build
```

### **Security Considerations**

1. **Add authentication** to API endpoints
2. **Rate limiting** on API calls
3. **HTTPS only** in production
4. **Environment variables** for API keys
5. **CORS restrictions** for production domains

---

## 📈 Performance Optimization

### **Backend Caching**

```python
# In tournament_api_backend.py
from flask_caching import Cache

cache = Cache(app, config={'CACHE_TYPE': 'simple'})

@app.route('/api/analysis/<symbol>')
@cache.cached(timeout=300)  # Cache for 5 minutes
def get_stock_analysis(symbol):
    # ... existing code
```

### **Frontend Caching**

```jsx
// Cache API responses
import { useQuery } from 'react-query';

const { data, isLoading } = useQuery(
  ['analysis', symbol],
  () => tournamentAPI.getAnalysis(symbol),
  { staleTime: 5 * 60 * 1000 } // 5 minutes
);
```

---

## 🎯 Migration Checklist

- [ ] Backend API running and tested
- [ ] Frontend components imported
- [ ] CSS styling applied
- [ ] Oracle AI component removed
- [ ] Tournament component added to stock pages
- [ ] Leaderboard added to sidebar (optional)
- [ ] Consensus alerts working
- [ ] API endpoints tested
- [ ] Mobile responsive verified
- [ ] Error states handled
- [ ] Loading states working
- [ ] Production deployment planned

---

## 💡 Tips for Success

1. **Start Small:** Test with one stock page first
2. **Keep Oracle AI:** Run both in parallel initially for comparison
3. **User Feedback:** Let users toggle between Oracle and Tournament
4. **Monitor Performance:** Track API response times
5. **Cost Tracking:** Monitor tournament API costs

---

## 📞 Support

**If you need help:**

1. Check console for errors
2. Verify API is running (`/api/health`)
3. Test API endpoints directly with curl
4. Check database has data
5. Verify CSS is loaded

**Common Issues:**

- CORS errors → Enable CORS in backend
- 404 errors → Check API base URL
- No data → Run tournament first to populate DB
- Styling issues → Import CSS file

---

## 🚀 You're Ready!

Your integration should now be complete. The tournament will display:

✅ Consensus recommendations from 4 AI teams
✅ Individual team analysis and reasoning
✅ Current tournament standings
✅ High conviction alerts when teams agree
✅ Professional, responsive UI

**Replace Oracle AI completely and let your users benefit from 4 AIs instead of 1!**
