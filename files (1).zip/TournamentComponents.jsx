/**
 * 🏆 AI TOURNAMENT REACT COMPONENTS
 * ==================================
 * 
 * Complete UI components for integrating tournament into stock analysis software
 * Replaces Oracle AI with 4-team tournament display
 */

import React, { useState, useEffect } from 'react';
import axios from 'axios';

// ============================================================================
// API CLIENT
// ============================================================================

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const tournamentAPI = {
  getAnalysis: async (symbol) => {
    const response = await axios.get(`${API_BASE_URL}/analysis/${symbol}`);
    return response.data;
  },
  
  getLeaderboard: async () => {
    const response = await axios.get(`${API_BASE_URL}/tournament/leaderboard`);
    return response.data;
  },
  
  getConsensusStocks: async (minAgreement = 3) => {
    const response = await axios.get(`${API_BASE_URL}/consensus/strong`, {
      params: { min_agreement: minAgreement }
    });
    return response.data;
  },
  
  getTeamStats: async (teamId) => {
    const response = await axios.get(`${API_BASE_URL}/team/${teamId}/stats`);
    return response.data;
  }
};

// ============================================================================
// MAIN TOURNAMENT ANALYSIS COMPONENT
// ============================================================================

export const TournamentAnalysis = ({ symbol }) => {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    loadAnalysis();
  }, [symbol]);

  const loadAnalysis = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await tournamentAPI.getAnalysis(symbol);
      setAnalysis(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="tournament-analysis loading">
        <div className="spinner"></div>
        <p>Loading AI Tournament Analysis...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="tournament-analysis error">
        <p>❌ Error loading analysis: {error}</p>
        <button onClick={loadAnalysis}>Retry</button>
      </div>
    );
  }

  if (!analysis || analysis.error) {
    return (
      <div className="tournament-analysis no-data">
        <p>No recent tournament analysis for {symbol}</p>
        <p className="hint">Analysis updates daily at market close</p>
      </div>
    );
  }

  return (
    <div className="tournament-analysis">
      <ConsensusView 
        consensus={analysis.consensus}
        symbol={symbol}
        teams={analysis.teams}
      />
      
      <button 
        className="details-toggle"
        onClick={() => setShowDetails(!showDetails)}
      >
        {showDetails ? '▼ Hide Team Details' : '▶ Show Team Details'}
      </button>
      
      {showDetails && (
        <TeamDetailsView teams={analysis.teams} />
      )}
    </div>
  );
};

// ============================================================================
// CONSENSUS VIEW (Main Recommendation)
// ============================================================================

const ConsensusView = ({ consensus, symbol, teams }) => {
  const { recommendation, strength, agree_count, total_teams, avg_confidence } = consensus;
  
  const getRecommendationColor = (rec) => {
    if (rec.includes('BUY')) return '#10b981'; // green
    if (rec.includes('SELL')) return '#ef4444'; // red
    return '#6b7280'; // gray
  };
  
  const getStrengthEmoji = (strength) => {
    if (strength === 'unanimous') return '✅✅✅';
    if (strength === 'strong') return '✅✅';
    if (strength === 'weak') return '✅';
    return '⚠️';
  };

  const getActionText = (rec) => {
    if (rec === 'STRONG_BUY') return 'STRONG BUY';
    if (rec === 'STRONG_SELL') return 'STRONG SELL';
    return rec;
  };

  return (
    <div className="consensus-view">
      <div className="consensus-header">
        <h3>🎯 AI Tournament Consensus</h3>
        <span className="tournament-badge">Day {teams[0]?.tournament_day || 0}/90</span>
      </div>
      
      <div 
        className="consensus-recommendation"
        style={{ borderColor: getRecommendationColor(recommendation) }}
      >
        <div className="recommendation-badge">
          <span 
            className="action-text"
            style={{ color: getRecommendationColor(recommendation) }}
          >
            {getActionText(recommendation)}
          </span>
          <span className="confidence">
            {Math.round(avg_confidence)}%
          </span>
        </div>
        
        <div className="consensus-strength">
          <span className="strength-emoji">{getStrengthEmoji(strength)}</span>
          <span className="agreement-text">
            {agree_count}/{total_teams} teams agree
          </span>
        </div>
      </div>
      
      {consensus.target_avg && (
        <div className="price-targets">
          <div className="target">
            <span className="label">Target:</span>
            <span className="value">${consensus.target_avg.toFixed(2)}</span>
          </div>
          <div className="stop">
            <span className="label">Stop:</span>
            <span className="value">${consensus.stop_avg.toFixed(2)}</span>
          </div>
        </div>
      )}
      
      <div className="team-summary">
        {teams.map(team => (
          <TeamSummaryBadge key={team.team_id} team={team} />
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// TEAM SUMMARY BADGE (Compact View)
// ============================================================================

const TeamSummaryBadge = ({ team }) => {
  const getActionEmoji = (action) => {
    if (action.includes('BUY')) return '🟢';
    if (action.includes('SELL')) return '🔴';
    return '⚪';
  };

  const getRankBadge = (teamName) => {
    // You can fetch actual rank from leaderboard
    return '';
  };

  return (
    <div className="team-summary-badge" title={team.reasoning_short}>
      <span className="team-rank">{getRankBadge(team.team_name)}</span>
      <span className="team-name">{team.team_name.split(' ')[0]}</span>
      <span className="action-emoji">{getActionEmoji(team.action)}</span>
      <span className="confidence">{Math.round(team.confidence)}%</span>
    </div>
  );
};

// ============================================================================
// TEAM DETAILS VIEW (Expanded)
// ============================================================================

const TeamDetailsView = ({ teams }) => {
  return (
    <div className="team-details-view">
      <h4>Team Recommendations</h4>
      <div className="teams-grid">
        {teams.map(team => (
          <TeamCard key={team.team_id} team={team} />
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// TEAM CARD (Individual Team Display)
// ============================================================================

const TeamCard = ({ team }) => {
  const [showFullReasoning, setShowFullReasoning] = useState(false);
  
  const getActionColor = (action) => {
    if (action.includes('BUY')) return '#10b981';
    if (action.includes('SELL')) return '#ef4444';
    return '#6b7280';
  };
  
  const getRankEmoji = (stats) => {
    if (!stats) return '';
    if (stats.return > 20) return '🥇';
    if (stats.return > 15) return '🥈';
    if (stats.return > 10) return '🥉';
    return '';
  };

  return (
    <div className="team-card">
      <div className="team-card-header">
        <div className="team-info">
          <span className="rank-emoji">{getRankEmoji(team.stats)}</span>
          <h5>{team.team_name}</h5>
        </div>
        {team.stats && (
          <div className="team-stats-compact">
            <span className="win-rate">Win: {team.stats.win_rate?.toFixed(1)}%</span>
            <span className="return">+{team.stats.return?.toFixed(1)}%</span>
          </div>
        )}
      </div>
      
      <div 
        className="team-recommendation"
        style={{ borderLeftColor: getActionColor(team.action) }}
      >
        <div className="action-row">
          <span 
            className="action"
            style={{ color: getActionColor(team.action) }}
          >
            {team.action}
          </span>
          <span className="confidence">{Math.round(team.confidence)}%</span>
        </div>
        
        {team.target_price && (
          <div className="price-row">
            <span className="price-item">
              Target: ${team.target_price.toFixed(2)}
            </span>
            <span className="price-item">
              Stop: ${team.stop_loss.toFixed(2)}
            </span>
          </div>
        )}
      </div>
      
      <div className="team-reasoning">
        <p className={showFullReasoning ? 'full' : 'short'}>
          {showFullReasoning ? team.reasoning_full : team.reasoning_short}
        </p>
        {team.reasoning_full && team.reasoning_full.length > 200 && (
          <button 
            className="read-more"
            onClick={() => setShowFullReasoning(!showFullReasoning)}
          >
            {showFullReasoning ? 'Show Less' : 'Read More'}
          </button>
        )}
      </div>
      
      {team.key_factors && team.key_factors.length > 0 && (
        <div className="key-factors">
          <strong>Key Factors:</strong>
          <ul>
            {team.key_factors.slice(0, 3).map((factor, idx) => (
              <li key={idx}>{factor}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// TOURNAMENT LEADERBOARD WIDGET
// ============================================================================

export const TournamentLeaderboard = ({ compact = false }) => {
  const [leaderboard, setLeaderboard] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLeaderboard();
    // Refresh every 5 minutes
    const interval = setInterval(loadLeaderboard, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const loadLeaderboard = async () => {
    try {
      const data = await tournamentAPI.getLeaderboard();
      setLeaderboard(data);
    } catch (err) {
      console.error('Failed to load leaderboard:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading leaderboard...</div>;
  if (!leaderboard) return null;

  return (
    <div className={`tournament-leaderboard ${compact ? 'compact' : ''}`}>
      <div className="leaderboard-header">
        <h3>🏆 Tournament Standings</h3>
        <span className="day-badge">
          Day {leaderboard.tournament_day}/{leaderboard.total_days}
        </span>
      </div>
      
      <div className="leaderboard-table">
        {leaderboard.teams.map(team => (
          <LeaderboardRow key={team.team_id} team={team} compact={compact} />
        ))}
      </div>
    </div>
  );
};

const LeaderboardRow = ({ team, compact }) => {
  const getRankEmoji = (rank) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return `${rank}.`;
  };

  if (compact) {
    return (
      <div className="leaderboard-row compact">
        <span className="rank">{getRankEmoji(team.rank)}</span>
        <span className="name">{team.team_name.split(' ')[0]}</span>
        <span className="return" style={{ color: team.return_pct > 0 ? '#10b981' : '#ef4444' }}>
          {team.return_pct > 0 ? '+' : ''}{team.return_pct.toFixed(1)}%
        </span>
      </div>
    );
  }

  return (
    <div className="leaderboard-row full">
      <div className="rank-col">
        <span className="rank-emoji">{getRankEmoji(team.rank)}</span>
      </div>
      <div className="team-col">
        <span className="team-name">{team.team_name}</span>
        <span className="win-rate">Win: {team.win_rate?.toFixed(1)}%</span>
      </div>
      <div className="stats-col">
        <span 
          className="return"
          style={{ color: team.return_pct > 0 ? '#10b981' : '#ef4444' }}
        >
          {team.return_pct > 0 ? '+' : ''}{team.return_pct.toFixed(1)}%
        </span>
        <span className="trades">{team.total_trades} trades</span>
      </div>
    </div>
  );
};

// ============================================================================
// CONSENSUS ALERTS
// ============================================================================

export const ConsensusAlerts = () => {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAlerts();
    const interval = setInterval(loadAlerts, 60 * 1000); // Update every minute
    return () => clearInterval(interval);
  }, []);

  const loadAlerts = async () => {
    try {
      const data = await tournamentAPI.getConsensusStocks(4); // Unanimous only
      setAlerts(data.stocks || []);
    } catch (err) {
      console.error('Failed to load alerts:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading || alerts.length === 0) return null;

  return (
    <div className="consensus-alerts">
      <h4>🔔 High Conviction Alerts</h4>
      <p className="alert-desc">All 4 teams agree on these stocks:</p>
      <div className="alerts-list">
        {alerts.map(alert => (
          <div key={alert.symbol} className="alert-item">
            <span className="symbol">{alert.symbol}</span>
            <span className={`action ${alert.recommendation.toLowerCase()}`}>
              {alert.recommendation}
            </span>
            <span className="confidence">
              {Math.round(alert.avg_confidence)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// EXPORT ALL COMPONENTS
// ============================================================================

export default {
  TournamentAnalysis,
  TournamentLeaderboard,
  ConsensusAlerts,
  TeamCard,
  ConsensusView
};
