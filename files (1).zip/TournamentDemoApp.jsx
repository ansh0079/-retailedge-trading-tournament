/**
 * 🎯 COMPLETE DEMO APP
 * ====================
 * 
 * Full working example of tournament integration
 * Copy this to see how everything works together
 */

import React, { useState } from 'react';
import { 
  TournamentAnalysis, 
  TournamentLeaderboard,
  ConsensusAlerts 
} from './TournamentComponents';
import './tournament_styles.css';

// ============================================================================
// MAIN APP COMPONENT
// ============================================================================

export const TournamentDemoApp = () => {
  const [selectedSymbol, setSelectedSymbol] = useState('AAPL');
  const [watchlist] = useState([
    'AAPL', 'MSFT', 'GOOGL', 'NVDA', 'TSLA', 'META', 'AMZN', 'AMD'
  ]);

  return (
    <div className="demo-app">
      <AppHeader />
      
      <div className="demo-layout">
        {/* Left Sidebar */}
        <div className="demo-sidebar">
          <WatchlistPanel 
            watchlist={watchlist}
            selectedSymbol={selectedSymbol}
            onSelectSymbol={setSelectedSymbol}
          />
          
          <TournamentLeaderboard compact={true} />
        </div>
        
        {/* Main Content */}
        <div className="demo-main">
          <ConsensusAlerts />
          
          <StockHeader symbol={selectedSymbol} />
          
          {/* Chart placeholder */}
          <div className="chart-placeholder">
            <p>📈 Chart would go here</p>
            <p className="hint">Integrate with your existing chart component</p>
          </div>
          
          {/* Tournament Analysis - THE MAIN FEATURE */}
          <TournamentAnalysis symbol={selectedSymbol} />
          
          {/* Fundamentals placeholder */}
          <div className="fundamentals-placeholder">
            <p>📊 Fundamentals would go here</p>
            <p className="hint">Your existing fundamentals component</p>
          </div>
        </div>
        
        {/* Right Sidebar (optional) */}
        <div className="demo-right-sidebar">
          <NewsPanel />
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// SUPPORTING COMPONENTS
// ============================================================================

const AppHeader = () => (
  <header className="demo-header">
    <div className="logo">
      <span className="logo-icon">📈</span>
      <h1>Stock Analysis Platform</h1>
    </div>
    <div className="header-actions">
      <button className="header-btn">
        🔔 Alerts
      </button>
      <button className="header-btn">
        ⚙️ Settings
      </button>
    </div>
  </header>
);

const WatchlistPanel = ({ watchlist, selectedSymbol, onSelectSymbol }) => (
  <div className="watchlist-panel">
    <h3>📋 Watchlist</h3>
    <div className="watchlist-items">
      {watchlist.map(symbol => (
        <div
          key={symbol}
          className={`watchlist-item ${symbol === selectedSymbol ? 'active' : ''}`}
          onClick={() => onSelectSymbol(symbol)}
        >
          <span className="symbol">{symbol}</span>
          <span className="price">$185.50</span>
          <span className="change positive">+2.4%</span>
        </div>
      ))}
    </div>
  </div>
);

const StockHeader = ({ symbol }) => (
  <div className="stock-header">
    <div className="stock-title">
      <h2>{symbol}</h2>
      <span className="company-name">Apple Inc.</span>
    </div>
    <div className="stock-price">
      <span className="price">$185.50</span>
      <span className="change positive">+$4.20 (+2.32%)</span>
    </div>
  </div>
);

const NewsPanel = () => (
  <div className="news-panel">
    <h3>📰 Latest News</h3>
    <div className="news-items">
      <div className="news-item">
        <p className="news-title">Apple announces new AI features</p>
        <span className="news-time">2h ago</span>
      </div>
      <div className="news-item">
        <p className="news-title">Q4 earnings beat expectations</p>
        <span className="news-time">5h ago</span>
      </div>
      <div className="news-item">
        <p className="news-title">New product launch scheduled</p>
        <span className="news-time">1d ago</span>
      </div>
    </div>
  </div>
);

// ============================================================================
// DEMO STYLES
// ============================================================================

const demoStyles = `
.demo-app {
  min-height: 100vh;
  background: #f3f4f6;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

.demo-header {
  background: white;
  border-bottom: 2px solid #e5e7eb;
  padding: 16px 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo {
  display: flex;
  align-items: center;
  gap: 12px;
}

.logo-icon {
  font-size: 32px;
}

.logo h1 {
  font-size: 24px;
  font-weight: 800;
  color: #111827;
  margin: 0;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.header-btn {
  padding: 8px 16px;
  background: #f3f4f6;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  color: #374151;
  transition: all 0.2s;
}

.header-btn:hover {
  background: #e5e7eb;
}

.demo-layout {
  display: grid;
  grid-template-columns: 280px 1fr 300px;
  gap: 24px;
  padding: 24px;
  max-width: 1800px;
  margin: 0 auto;
}

.demo-sidebar {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.demo-main {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.demo-right-sidebar {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.watchlist-panel {
  background: white;
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.watchlist-panel h3 {
  font-size: 16px;
  font-weight: 700;
  color: #111827;
  margin: 0 0 12px 0;
}

.watchlist-items {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.watchlist-item {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 8px;
  padding: 10px 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
}

.watchlist-item:hover {
  background: #f3f4f6;
}

.watchlist-item.active {
  background: #dbeafe;
  border-left: 3px solid #3b82f6;
}

.watchlist-item .symbol {
  font-weight: 700;
  color: #111827;
}

.watchlist-item .price {
  font-weight: 600;
  color: #4b5563;
  font-size: 14px;
}

.watchlist-item .change {
  font-weight: 700;
  font-size: 13px;
}

.watchlist-item .change.positive {
  color: #10b981;
}

.watchlist-item .change.negative {
  color: #ef4444;
}

.stock-header {
  background: white;
  border-radius: 12px;
  padding: 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.stock-title h2 {
  font-size: 32px;
  font-weight: 800;
  color: #111827;
  margin: 0;
}

.stock-title .company-name {
  font-size: 16px;
  color: #6b7280;
  font-weight: 600;
}

.stock-price {
  text-align: right;
}

.stock-price .price {
  display: block;
  font-size: 36px;
  font-weight: 800;
  color: #111827;
}

.stock-price .change {
  font-size: 18px;
  font-weight: 700;
}

.stock-price .change.positive {
  color: #10b981;
}

.chart-placeholder,
.fundamentals-placeholder {
  background: white;
  border-radius: 12px;
  padding: 48px;
  text-align: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 2px dashed #e5e7eb;
}

.chart-placeholder p,
.fundamentals-placeholder p {
  font-size: 18px;
  font-weight: 600;
  color: #6b7280;
  margin: 8px 0;
}

.chart-placeholder .hint,
.fundamentals-placeholder .hint {
  font-size: 14px;
  color: #9ca3af;
  font-weight: 400;
}

.news-panel {
  background: white;
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.news-panel h3 {
  font-size: 16px;
  font-weight: 700;
  color: #111827;
  margin: 0 0 12px 0;
}

.news-items {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.news-item {
  padding: 12px;
  background: #f9fafb;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
}

.news-item:hover {
  background: #f3f4f6;
}

.news-item .news-title {
  font-size: 14px;
  font-weight: 600;
  color: #374151;
  margin: 0 0 4px 0;
  line-height: 1.4;
}

.news-item .news-time {
  font-size: 12px;
  color: #6b7280;
}

@media (max-width: 1400px) {
  .demo-layout {
    grid-template-columns: 280px 1fr;
  }
  
  .demo-right-sidebar {
    display: none;
  }
}

@media (max-width: 900px) {
  .demo-layout {
    grid-template-columns: 1fr;
  }
  
  .demo-sidebar,
  .demo-right-sidebar {
    display: none;
  }
}
`;

// Inject styles
const styleSheet = document.createElement("style");
styleSheet.textContent = demoStyles;
document.head.appendChild(styleSheet);

export default TournamentDemoApp;
